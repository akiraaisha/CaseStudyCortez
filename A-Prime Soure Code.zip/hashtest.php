<?php
    echo password_hash("4153108",PASSWORD_DEFAULT);
    $hash = '$2y$10$2N6E95BEFl9kJGELiWEHb.Gy/CqDQP0PeFMkPyTAZAkxBjokv3l5G';

    if (password_verify('4153108', $hash)) {
        echo "Correct\n";}
    else {
            echo "Wrong";
        }
?>