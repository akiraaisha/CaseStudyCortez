<?php
?>
<!DOCTYPE html>
<html>
<head>
    <title>A-Prime</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/semantic.css">
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="css/semantic.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/components/dropdown.css">
    <script src="css/components/dropdown.js"></script>
    <link rel="stylesheet" type="text/css" href="css/components/form.css">
    <link rel="stylesheet" type="text/css" href="css/components/button.css">
    <script src="css/components/form.js"></script>
    <link rel="stylesheet" type="text/css" href="css/components/divider.css">
    <link rel="stylesheet" type="text/css" href="css/components/input.css.css">
    <link rek="stylesheet" type="text/css" href="../css/styles.css">
    <style>
        body {
            -webkit-font-smoothing: antialiased;
            -moz-font-smoothing: grayscale;
            background: #dedede;
        }
        th {text-align: center;
            color: #35a862;
            background-color: #d9ffc7;
        }
        tr:nth-child(even) {
            background: #ffffff;
        }
        tr:nth-child(odd) {
            background: #eaeaea;
        }
        body {
            -webkit-font-smoothing: antialiased;
            -moz-font-smoothing: grayscale;
        }

        .ui.borderless.menu {
            background-color: #f8f8f8;
            box-shadow: none;
            flex-wrap: wrap;
            border: none;
            padding-left: 0;
            padding-right: 0;
        }

        .ui.borderless.menu .header.item {
            font-size: 18px;
            font-weight: 400;
        }

        .ui.mobile.only.grid .ui.menu .ui.vertical.menu {
            display: none;
        }

        .ui.mobile.only.grid .ui.vertical.menu .dropdown.icon {
            float: unset;
        }

        .ui.mobile.only.grid .ui.vertical.menu .dropdown.icon:before {
            content: "\f0d7";
        }

        .ui.mobile.only.grid .ui.vertical.menu .ui.dropdown.item .menu {
            position: static;
            width: 100%;
            background-color: unset;
            border: none;
            box-shadow: none;
        }

        .ui.mobile.only.grid .ui.vertical.menu .ui.dropdown.item .menu {
            margin-top: 6px;
        }

        .ui.container > .ui.message {
            background-color: rgb(238, 238, 238);
            box-shadow: none;
            padding: 5rem 4rem;
            margin-top: 1rem;
        }

        .ui.message h1.ui.header {
            font-size: 4.5rem;
        }

        .ui.message p.lead {
            font-size: 1.3rem;
            color: #333333;
            line-height: 1.4;
            font-weight: 300;
        }
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
    </style>
</head>
<body>
<div class="ui tablet computer only padded grid">
    <div class="ui borderless fluid huge menu">
        <div class="ui container">
            <a class="header item">A-Prime Homeowner Association</a>
            <a class="item" href="index.php">Home</a>
            <a class="item" href="add.php">Add Member</a>
            <a class="item active" href="payment.php">Payment</a>
            <a class="item" href="logout.php">Logout</a>
            <a>
                <div class="ui right aligned" style="width:95%; margin-left: auto;margin-right: auto;margin-top: 3.6em; text-align: right"></div>
            </a>
        </div>
    </div>
</div>

<table class="ui table celled" style=" margin-left: auto;margin-right: auto;margin-top: 2em; margin-bottom: 2em;">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Jan</th>
        <th>Feb</th>
        <th>Mar</th>
        <th>Apr</th>
        <th>May</th>
        <th>Jun</th>
        <th>Jul</th>
        <th>Aug</th>
        <th>Sept</th>
        <th>Oct</th>
        <th>Nov</th>
        <th>Dec</th>
        <th>Total</th>
    </tr>
